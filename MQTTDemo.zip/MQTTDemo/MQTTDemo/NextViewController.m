//
//  NextViewController.m
//  MQTTDemo
//
//  Created by 刘倩倩 on 17/4/6.
//  Copyright © 2017年 liuqianqian. All rights reserved.
//

#define localHost @"tcp://192.168.4.22"
#define localPort 1883
#define TopicSend @"recivie"
#define TopicRecivie @"sender"

#import "NextViewController.h"
#import "MQTTSessionManager.h"

@interface NextViewController ()<MQTTSessionManagerDelegate>
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;

@property (weak, nonatomic) IBOutlet UILabel *resultLabel;

@property (weak, nonatomic) IBOutlet UITextField *textField;

@property (nonatomic,strong) MQTTSessionManager *sessionManager;
@property (nonatomic,strong) NSTimer *timer;

@end

@implementation NextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _sessionManager = [[MQTTSessionManager alloc]init];
    NSString *clientId = [UIDevice currentDevice].identifierForVendor.UUIDString;
    [_sessionManager connectTo:localHost //服务器地址
                         port:1883 //服务端端口号
                          tls:true //是否使用tls协议，mosca是支持tls的，如果使用了要设置成true
                    keepalive:60 //心跳时间，单位秒，每隔固定时间发送心跳包
                        clean:false //session是否清除，这个需要注意，如果味false，代表保持登录，如果客户端离线了再次登录就可以接收到离线消息
                         auth:true //是否使用登录验证，和下面的user和pass参数组合使用
                         user:@"lqq" //用户名
                         pass:@"123456" //密码
                    willTopic:@"hahah" //下面四个参数用来设置如果客户端离线发送给其它客户端消息，当前参数是哪个topic用来传输离线消息，这里的离线消息都指的是客户端掉线后发送的掉线消息
                         will:[@"我下线啦" dataUsingEncoding:NSUTF8StringEncoding] //自定义的离线消息，约定好格式就可以了
                      willQos:1 //接收离线消息的级别
               willRetainFlag:false
                 withClientId:clientId]; //客户端id，需要特别指出的是这个id需要全局唯一，因为服务端是根据这个来区分不同的客户端的，默认情况下一个id登录后，假如有另外的连接以这个id登录，上一个连接会被踢下线
    
    _sessionManager.delegate = self;
    
    //定时器实现重连
    _timer = [NSTimer scheduledTimerWithTimeInterval:30.0f target:self selector:@selector(monitorStatus) userInfo:nil repeats:YES];
}

- (void)monitorStatus
{
    switch (_sessionManager.state) {
        case MQTTSessionStatusConnected:
            self.stateLabel.text = @"连接成功！";
            break;
        case MQTTSessionStatusConnecting:
            self.stateLabel.text = @"连接中！";
            break;
        default:
            self.stateLabel.text = @"连接失败";
            break;
    }
    
    
    
    if (_sessionManager.state == MQTTSessionStatusClosed) {
        
        [_sessionManager connectToLast];
    }
}

- (IBAction)Connect:(UIButton *)sender {
    
}

- (IBAction)subscribe:(UIButton *)sender {
    
    _sessionManager.subscriptions = @{
                                      TopicRecivie:@(2)
                                      };
}

- (IBAction)unsubscribe:(UIButton *)sender {
}

- (IBAction)publish:(id)sender {
    
    [_sessionManager sendData:[_textField.text dataUsingEncoding:NSUTF8StringEncoding] topic:TopicSend qos:MQTTQosLevelExactlyOnce retain:YES];
}

- (IBAction)disconnect:(id)sender {
    
    [_sessionManager disconnect];
}
#pragma mark  - MQTTSessionManagerDelegate
- (void)handleMessage:(NSData *)data onTopic:(NSString *)topic retained:(BOOL)retained
{
    NSString *str = [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    self.resultLabel.text =  str;
}

- (void)messageDelivered:(UInt16)msgID
{
    NSLog(@"msgId:%d",msgID);
}

@end
