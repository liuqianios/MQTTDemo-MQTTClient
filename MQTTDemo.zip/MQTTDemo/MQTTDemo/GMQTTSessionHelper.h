//
//  GMQTTSessionHelper.h
//  MQTTDemo
//
//  Created by 刘倩倩 on 17/4/6.
//  Copyright © 2017年 liuqianqian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GMQTTSessionHelper : NSObject

+ (instancetype)sharedMQTTSessionHelper;

- (void)connect;
@end
