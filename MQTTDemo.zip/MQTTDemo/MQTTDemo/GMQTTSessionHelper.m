//
//  GMQTTSessionHelper.m
//  MQTTDemo
//
//  Created by 刘倩倩 on 17/4/6.
//  Copyright © 2017年 liuqianqian. All rights reserved.
//

#import "GMQTTSessionHelper.h"
#import "MQTTSessionManager.h"
#import "MQTTCFSocketTransport.h"
#import "MQTTSessionSynchron.h"


@interface GMQTTSessionHelper ()

@end

@implementation GMQTTSessionHelper
static MQTTSession *_session;

+ (instancetype)sharedMQTTSessionHelper
{
    static GMQTTSessionHelper *_helper;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _helper = [[GMQTTSessionHelper alloc]init];
        _session = [[MQTTSession alloc]init];
    });
    return _helper;
}



@end
