//
//  ViewController.m
//  MQTTDemo
//
//  Created by 刘倩倩 on 17/4/5.
//  Copyright © 2017年 liuqianqian. All rights reserved.
//

#import "ViewController.h"
#import "MQTTSessionManager.h"
#import "MQTTCFSocketTransport.h"
#import "MQTTSessionSynchron.h"

#define localHost @"192.168.4.22"
#define localPort 1883
#define TopicSend @"recivie"
#define TopicRecivie @"sender"
#define willTopc1 @"willTopic1"
#define willTopc2 @"willTopic2"

@interface ViewController ()<MQTTSessionDelegate>

@property (nonatomic,strong) MQTTSession *session;
@property (nonatomic,strong) NSTimer *timer;

@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    MQTTCFSocketTransport *transport = [[MQTTCFSocketTransport alloc]init];
    transport.host = localHost;
    transport.port = localPort;
    
    //    NSString *clientID = [UIDevice currentDevice].identifierForVendor.UUIDString;
    
    self.session.transport = transport;

    
    self.session.delegate = self;
    
    //定时器实现重连
//    _timer = [NSTimer scheduledTimerWithTimeInterval:30.0f target:self selector:@selector(monitorStatus) userInfo:nil repeats:YES];
}

- (void)monitorStatus
{
    if (self.session.status == MQTTSessionStatusClosed) {
        [self.session connect];
    }
}

- (IBAction)createNewSession:(UIButton *)sender {
    
    BOOL connented = [self.session connectAndWaitTimeout:1];
    
//    [self.session connectWithConnectHandler:^(NSError *error) {
//        
//    }];
    
    NSLog(@"conneted %d",connented);
    __weak typeof(self) weakSelf = self;
    self.session.connectHandler = ^(NSError *error){
        if (!error) {
            [sender setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
            
        }else
        {
            [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            NSLog(@"%@",error.localizedFailureReason);
        }
    };
    
    self.session.connectionHandler = ^(MQTTSessionEvent event){
        if (event == MQTTSessionEventConnected) {
            weakSelf.resultLabel.text = @"连接成功！";
        }
    };
    
    self.session.messageHandler = ^(NSData* message, NSString* topic){
        NSString *result = [[NSString alloc] initWithData:message  encoding:NSUTF8StringEncoding];
        NSLog(@"message---%@",result);
    };
    
    /*
     //重新连接
     [self.session connect];*/
}


- (IBAction)disConnect:(id)sender {
    
    //断开连接
    [self.session disconnect];
    

}

- (IBAction)close:(id)sender {
    
    //关闭
//    [self.session close];
    
    [self.session closeWithDisconnectHandler:^(NSError *error) {
        if (!error) {
            [sender setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
             self.resultLabel.text = @"关闭成功！";
        }else
        {
            [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
    }];
}
- (IBAction)subscribe:(UIButton *)sender {
    //订阅一个topic
    
    [self.session subscribeToTopics:@{
                                     TopicRecivie:@(2),
                                     willTopc1:@(2)
                                     }subscribeHandler:^(NSError *error, NSArray<NSNumber *> *gQoss) {
                                         
                                         if (!error) {
                                             [sender setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
                                             self.resultLabel.text = @"订阅成功！";
                                         }else
                                         {
                                             [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
                                         }
                                     }];
    
//    [self.session  subscribeToTopic:TopicRecivie atLevel:MQTTQosLevelAtMostOnce subscribeHandler:^(NSError *error, NSArray<NSNumber *> *gQoss) {
//        
//        if (!error) {
//            [sender setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
//            self.resultLabel.text = @"订阅成功！";
//        }else
//        {
//            [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//        }
//        
//    }];
}


- (IBAction)removeSubscribe:(UIButton *)sender {
    
    [self.session unsubscribeTopic:TopicRecivie unsubscribeHandler:^(NSError *error) {
        
        if (!error) {
            [sender setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
             self.resultLabel.text = @"取消订阅成功！";
        }else
        {
            [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
    }];
}


- (IBAction)publish:(UIButton *)sender {
    
    NSData *data = [self.textField.text dataUsingEncoding:NSUTF8StringEncoding];
    [self.session publishData:data onTopic:TopicSend retain:NO qos:MQTTQosLevelAtLeastOnce publishHandler:^(NSError *error) {
        if (!error) {
            [sender setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        }else
        {
            [sender setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        }
    }];
}

#pragma mark - MQTTSessionDelegate
- (void)newMessage:(MQTTSession *)session
              data:(NSData *)data
           onTopic:(NSString *)topic
               qos:(MQTTQosLevel)qos
          retained:(BOOL)retained
               mid:(unsigned int)mid
{
    NSString *result = [[NSString alloc] initWithData:data  encoding:NSUTF8StringEncoding];
    
    self.resultLabel.text = result;
}

//断网情况下不会主动进行Connect，调用connect就会走这个方法
- (void)connectionError:(MQTTSession *)session error:(NSError *)error{
    NSLog(@"=========错误:%@",error);
}

//MQTT 断开连接以后，会回调该方法
- (void)connectionClosed:(MQTTSession *)session
{
    //这里可以实现重连
    //Tips：断开重连的过程中如果session的cleanSession字段为True，则服务器不会存会话信息，重连以后需要重新订阅主题topic,才能接收到消息。cleanSession为false则再次登录则可以继续收到订阅信息。
    [self.session connect];
}


- (MQTTSession *)session
{
    if (!_session) {
        NSString *clientId = [UIDevice currentDevice].identifierForVendor.UUIDString;
        _session = [[MQTTSession alloc]initWithClientId:clientId userName:nil password:nil keepAlive:60 cleanSession:false willTopic:willTopc2 willMsg:[@"我下线啦" dataUsingEncoding:NSUTF8StringEncoding] willQoS:2 willRetainFlag:NO];
//        _session = [[MQTTSession alloc]init];
//        _session.cleanSessionFlag = false;
        

    }
    return _session;
}

@end
